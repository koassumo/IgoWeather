package ru.geekbrains.igoweather.mvp.presenter;

public class Presenter {
}
