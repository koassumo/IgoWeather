package ru.geekbrains.igoweather.mvp.view;

public class View {

}
