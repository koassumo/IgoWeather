package ru.geekbrains.igoweather.mvp.model;

import java.util.ArrayList;
import java.util.Arrays;

public class Model {
    private ArrayList<String> re1 = new ArrayList<>(Arrays.asList("One","Two","Three"));

}
